<?php

return [
    'title' => 'Patients',
    'subtitle' => 'Patient registry and medical workflow',
    'add' => 'Register Patient',
    'create_title' => 'Register Patient',
    'create_subtitle' => 'Add a new patient to a campaign',
    'edit_title' => 'Edit Patient',
    'edit_subtitle' => 'Update patient information',
    'show_title' => 'Patient Profile',
    'show_subtitle' => 'Patient details and medical classification',

    'brief' => [
        'title' => 'Patient Clinical Brief',
        'subtitle' => 'Pre-operative clinical review snapshot',
        'preop_review' => 'Pre-op clinical review',
        'print' => 'Print',
        'full_profile' => 'Full Profile',
        'at_a_glance' => 'At a glance',
        'at_a_glance_hint' => 'Surgery-critical facts for the operating team.',
        'clinical_alerts' => 'Clinical alerts',
        'records_label' => 'Medical records',
        'surgery_context' => 'Surgery & Status',
        'priority_clinical' => 'Key Clinical Data',
        'priority_clinical_hint' => 'Highest-yield findings before entering theatre.',
        'demographics' => 'Patient Identity',
        'workflow_progress' => 'Workflow progress',
        'stage_records' => 'Clinical course by stage',
        'stage_records_hint' => 'Latest completed entry for each workflow stage.',
        'stage_n' => 'Stage :n',
        'clinical_phases' => 'Full Clinical File',
        'clinical_phases_hint' => 'Complete dossier grouped by clinical phase.',
        'media' => 'Photos, Videos & Files',
        'upload_media' => 'Upload',
        'upload_files_label' => 'Select files',
        'upload_files_hint' => 'Images, videos (MP4, MOV, WebM), or documents. Up to 10 files, 50 MB each.',
        'upload_notes_placeholder' => 'Optional note (e.g. CT scan, audiology video)',
        'no_media' => 'No photos, videos, or files uploaded yet.',
        'photos_videos' => 'Photos & Videos',
        'documents' => 'Documents & Other Files',
        'records_snapshot' => ':total medical record(s) — showing the latest entry per stage.',
        'records_history_hint' => 'Older entries for the same stage are hidden on this brief. Open the full profile for complete history.',
        'view_all_records' => 'View all records',
        'stage_latest' => 'Latest: :date',
        'stage_record_count' => ':count record(s)',
        'view_record' => 'Open record',
        'show_more_fields' => 'Show :count more',
        'show_less_fields' => 'Show less',
        'collapse_phases' => 'Collapse',
        'expand_phases' => 'Expand full clinical file',
    ],

    'show' => [
        'back' => 'Back to Patient',
    ],

    'admission' => [
        'admitted' => 'Admitted',
        'not_admitted' => 'Not Admitted',
    ],

    'record_status' => [
        'active' => 'Active',
        'closed' => 'Closed',
        'archived' => 'Archived',
    ],

    'age' => [
        'years' => ':years years',
        'months' => ':months months',
    ],

    'stats' => [
        'total' => 'Total Patients',
        'accepted' => 'Accepted',
        'rejected' => 'Rejected',
        'postponed' => 'Postponed',
        'cancelled' => 'Cancelled',
        'admitted' => 'Admitted',
        'completed' => 'Completed',
    ],

    'filters' => [
        'title' => 'Filters',
        'search' => 'Search',
        'search_placeholder' => 'Name, file number, contact…',
        'campaign' => 'Campaign',
        'all_campaigns' => 'All campaigns',
        'eligibility' => 'Eligibility Status',
        'all_eligibility' => 'All statuses',
        'stage' => 'Current Stage',
        'all_stages' => 'All stages',
        'admission' => 'Admission Status',
        'all_admission' => 'All',
        'gender' => 'Gender',
        'all_genders' => 'All',
        'created_from' => 'Created From',
        'created_to' => 'Created To',
        'apply' => 'Apply',
        'reset' => 'Reset',
    ],

    'table' => [
        'name' => 'Patient Name',
        'file_number' => 'Patient Code',
        'campaign' => 'Campaign',
        'age' => 'Age',
        'gender' => 'Gender',
        'eligibility' => 'Eligibility',
        'stage' => 'Current Stage',
        'admission' => 'Admission',
        'created_at' => 'Created',
        'actions' => 'Actions',
    ],

    'sections' => [
        'basic' => 'Basic Information',
        'campaign' => 'Campaign Information',
        'medical' => 'Medical Classification',
        'contact' => 'Contact Information',
        'attachments' => 'Attachments',
        'screening' => 'Screening & Eligibility',
        'screening_hint' => 'Initial screening data (hearing, speech, eligibility). All fields are optional.',
        'pre_op_create_hint' => 'Optional. Any data entered here is saved as a Pre Operation medical record that you can view and edit later.',
        'audit' => 'Record Information',
    ],

    'fields' => [
        'campaign' => 'Campaign',
        'patient_name' => 'Patient Name',
        'photo' => 'Patient Photo',
        'file_number' => 'Patient Code',
        'date_of_birth' => 'Date of Birth',
        'age' => 'Age',
        'gender' => 'Gender',
        'contact_number' => 'Contact Number',
        'eligibility_status' => 'Eligibility Status',
        'current_stage' => 'Current Stage',
        'admission_status' => 'Admission Status',
        'record_status' => 'Record Status',
        'notes' => 'Notes',
        'created_by' => 'Created By',
        'updated_by' => 'Updated By',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
        'attachment' => 'Attachment',
        'attachment_notes' => 'Attachment Notes',
        'surgery_day_number' => 'Surgery Day',
        'surgery_day_number_value' => 'Day :day',
        'rank' => 'Rank',
        'surgical_side' => 'Surgical Side',
        'approval_reason' => 'Approval / Rejection Reason',
        'height_cm' => 'Height (cm)',
        'weight_kg' => 'Weight (kg)',
    ],

    'measurements' => [
        'height_value' => ':value cm',
        'weight_value' => ':value kg',
    ],

    'hints' => [
        'file_number_auto' => 'Auto-generated as country + year + month + sequence (e.g. SYR2026071). Unique system-wide.',
        'file_number_generated_on_save' => 'Generated automatically on save from the campaign country and registration date. Cannot be changed later.',
    ],

    'placeholders' => [
        'patient_name' => 'Full patient name',
        'file_number' => 'e.g. P-2026-001',
        'contact_number' => 'e.g. +966501234567',
        'height_cm' => 'e.g. 120',
        'weight_kg' => 'e.g. 32.5',
        'notes' => 'Clinical or administrative notes…',
        'select_campaign' => 'Select campaign',
        'select_eligibility' => 'Select eligibility status',
        'select_stage' => 'Select stage',
    ],

    'tabs' => [
        'overview' => 'Overview',
        'clinical' => 'Clinical File',
        'workflow' => 'Medical Workflow',
        'records' => 'Medical Records',
        'history' => 'Stage History',
        'attachments' => 'Attachments',
        'reports' => 'Reports',
        'transportation' => 'Transportation',
        'activities' => 'Activities',
    ],

    'clinical' => [
        'title' => 'Clinical File',
        'subtitle' => 'Complete patient data grouped by pre-operative, intra-operative, and post-operative phases.',
        'field' => 'Field',
        'value' => 'Value',
        'source' => 'Source',
        'no_phase_data' => 'No data recorded for this phase yet.',
        'source_screening' => 'Screening',
        'source_patient' => 'Patient Profile',
        'edit_screening' => 'Edit Screening Data',
        'open_link' => 'Open link',
    ],

    'future' => [
        'workflow' => 'Medical workflow will be available when the workflow module is enabled.',
        'records' => 'Medical records will appear here when the Medical Records module is enabled.',
        'history' => 'Stage history will appear here when the Stage History module is enabled.',
        'reports' => 'Patient reports will appear here when the Reports module is enabled.',
    ],

    'photo' => [
        'choose' => 'Choose Photo',
        'change' => 'Change Photo',
        'remove' => 'Remove Photo',
        'hint' => 'Optional. JPEG, PNG or WebP, max 2 MB.',
    ],

    'campaign' => [
        'title' => 'Campaign Patients',
        'add_patient' => 'Add Patient',
        'empty' => 'No patients registered for this campaign yet.',
    ],

    'actions' => [
        'view' => 'View',
        'edit' => 'Edit',
        'delete' => 'Delete',
        'download' => 'Download',
        'upload' => 'Upload Attachment',
        'remove_attachment' => 'Remove',
    ],

    'operative_note_export' => [
        'button' => 'Export Operative Note',
        'modal_title' => 'Export Operative Note',
        'modal_subtitle' => 'Download the intra-operative PDF for this patient.',
        'latest_label' => 'Latest operation',
        'latest_badge' => 'Latest',
        'export_latest' => 'Export latest Operative Note',
        'or_choose' => 'Or choose a previous operation',
        'export_row' => 'Export',
        'columns' => [
            'date' => 'Date',
            'surgeon' => 'Surgeon',
            'side' => 'Side',
            'company' => 'Company',
            'implant' => 'Implant',
            'action' => 'Action',
        ],
    ],

    'import' => [
        'title' => 'Patient Imports',
        'subtitle' => 'Import basic patient demographics for a selected campaign',
        'create_title' => 'Import Patients',
        'create_subtitle' => 'Select a campaign, upload the Excel template, and import basic patient information only',
        'show_title' => 'Import Batch',
        'show_subtitle' => 'Review and approve imported data',
        'download_template' => 'Download Template',
        'file_hint' => 'Use the official template (.xlsx). Row 1 must match the column headers exactly.',
        'column_required' => 'Required',
        'column_optional' => 'Optional',

        'template_table' => [
            'column' => 'Column',
            'label' => 'Label',
            'required' => 'Required',
            'rules' => 'Validation',
        ],

        'review_table' => [
            'errors' => 'Errors / Notes',
        ],

        'column_hints' => [
            'patient_name' => 'Required. Max 255 characters.',
            'date_of_birth' => 'Optional. YYYY-MM-DD or Excel date. Defaults to 2000-01-01 if empty.',
            'gender' => 'Optional. Use: male or female. Defaults to male if empty.',
            'height_cm' => 'Optional. Number between 20 and 250.',
            'weight_kg' => 'Optional. Number between 0.5 and 500.',
            'contact_number' => 'Optional. Max 30 characters.',
        ],

        'default_notes' => [
            'Empty date of birth → 2000-01-01 on approval.',
            'Empty gender → male on approval.',
            'Eligibility status defaults to accepted.',
        ],

        'status' => [
            'uploaded' => 'Uploaded',
            'processing' => 'Processing',
            'review' => 'Awaiting Review',
            'approved' => 'Approved',
            'completed' => 'Completed',
            'failed' => 'Failed',
        ],

        'stats' => [
            'total' => 'Total Imports',
            'pending_review' => 'Pending Review',
            'processing' => 'Processing',
            'completed' => 'Completed',
            'failed' => 'Failed',
            'patients_imported' => 'Patients Imported',
        ],

        'table' => [
            'date' => 'Import Date',
            'campaign' => 'Campaign',
            'uploaded_by' => 'Uploaded By',
            'rows' => 'Rows',
            'valid' => 'Valid',
            'invalid' => 'Invalid',
            'duplicates' => 'Duplicates',
            'imported' => 'Imported',
            'status' => 'Status',
            'actions' => 'Actions',
        ],

        'row_status' => [
            'valid' => 'Valid',
            'invalid' => 'Invalid',
            'duplicate' => 'Duplicate',
            'imported' => 'Imported',
        ],

        'fields' => [
            'campaign' => 'Campaign',
            'file' => 'Excel File',
            'notes' => 'Notes',
            'patient_name' => 'Patient Name',
            'date_of_birth' => 'Date of Birth',
            'gender' => 'Gender',
            'height_cm' => 'Height (cm)',
            'weight_kg' => 'Weight (kg)',
            'contact_number' => 'Contact Number',
        ],

        'sections' => [
            'upload' => 'Upload File',
            'instructions' => 'Instructions',
            'reference' => 'Reference Codes',
            'template_columns' => 'Template Columns',
            'gender_values' => 'Gender Values',
            'defaults' => 'Default Values',
            'statistics' => 'Import Statistics',
            'review' => 'Row Review',
            'approval' => 'Approval',
        ],

        'instructions' => [
            'Select the target campaign before uploading the file.',
            'Download the official Excel template and keep row 1 exactly as exported.',
            'Use one sheet only with these columns in order: patient_name, date_of_birth, gender, height_cm, weight_kg, contact_number.',
            'Only patient_name is required on every patient row. All other columns are optional.',
            'If a column has a value, it will be validated (date format, gender, numeric height/weight, etc.).',
            'Gender (if provided) must be: male or female.',
            'Date of birth format: YYYY-MM-DD (example: 2015-06-20). Excel date cells are also accepted.',
            'Rows with validation errors are rejected; valid rows can still be approved.',
        ],

        'defaults' => [
            'unnamed_patient' => 'Imported patient (row :row)',
        ],

        'campaign_workbook' => [
            'title' => 'Campaign Workbook Import',
            'instructions' => [],
        ],

        'actions' => [
            'upload' => 'Upload File',
            'approve' => 'Approve Import',
            'download_errors' => 'Export Errors',
            'view' => 'View',
        ],

        'messages' => [
            'uploaded' => 'File uploaded and queued for processing. Refresh to check status.',
            'processing_wait' => 'Processing the file. This page will refresh automatically.',
            'queued_wait' => 'Waiting for background processing to start. This page will refresh automatically.',
            'queue_stuck' => 'Processing is taking longer than expected. Ask your administrator to run the queue worker, or set PATIENT_IMPORT_SYNC=true in .env.',
            'approved' => ':count patient(s) imported successfully.',
            'not_reviewable' => 'This batch is not in a reviewable state.',
            'validation_failed_title' => 'File could not be imported',
            'empty_file' => 'The file contains no patient rows. Row 1 must be the header and patient data must start from row 2. Required columns: :required. Expected column order: :columns.',
            'file_missing' => 'Import file not found on storage.',
            'header_missing' => 'Row 1 is empty or missing column headers. Copy the header row exactly from the import template without changing column names or order. Expected columns: :columns. Required columns: :required.',
            'invalid_template' => 'The file does not match the import template. Missing columns: :missing. Extra columns: :extra. Expected order: :expected. Found in row 1: :found. Required field on each row: :required. Download the template and paste your data starting from row 2 without changing the headers.',
            'invalid_template_order' => 'Column order in row 1 is incorrect. Expected order: :expected. Found: :found. Do not rearrange or rename the template headers.',
            'missing_column' => 'Required column ":column" is missing from the file.',
            'processing_failed' => 'An unexpected error occurred while processing the file. Please try again or contact support.',
            'invalid_number' => '":field" must be a number.',
            'out_of_range' => '":field" must be between :min and :max.',
            'too_long' => '":field" must not exceed :max characters.',
            'required' => 'Field ":field" is required.',
            'invalid_date' => 'Invalid date format. Use YYYY-MM-DD.',
            'future_date' => 'Date of birth cannot be a future date.',
            'invalid_gender' => 'Invalid gender. Use: male or female.',
            'invalid_eligibility' => 'Invalid eligibility status code: :code',
            'invalid_admission' => 'Invalid admission status. Use: admitted or not_admitted.',
            'invalid_stage' => 'Invalid stage code: :code',
            'invalid_campaign' => 'Campaign not found for code: :code',
            'campaign_mismatch' => 'Campaign code does not match the selected campaign (expected: :expected).',
            'duplicate_in_file' => 'Duplicate :field in file (first seen at row :row).',
            'duplicate_in_database' => 'Patient code ":file_number" already exists in the system.',
            'duplicate_name_in_database' => 'Patient ":name" already exists in this campaign.',
            'campaign_required_workbook' => 'A campaign must be selected when importing a campaign workbook.',
            'campaign_required' => 'Please select a campaign before uploading.',
            'workbook_not_supported' => 'This file looks like a campaign workbook (sheets found: :sheets). Patient import accepts only the basic single-sheet template. Download the template and use one sheet with these columns in order: :columns. Required columns: :required.',
            'no_importable_rows' => 'No valid rows found to import.',
            'confirm_approve' => 'Approve this import? This will create :count patient record(s) and cannot be undone.',
        ],
    ],

    'export' => [
        'create_title' => 'Export Patients',
        'create_subtitle' => 'Download patient data for a selected campaign',

        'fields' => [
            'campaign' => 'Campaign',
            'all_stages' => 'All medical record stages',
        ],

        'sections' => [
            'options' => 'Export Options',
            'medical_records' => 'Medical Records',
            'instructions' => 'Instructions',
            'structure' => 'File Structure',
        ],

        'sheets' => [
            'patients' => 'Patients',
        ],

        'hints' => [
            'basic_sheet' => 'The Patients sheet is always included with basic demographic and workflow information.',
            'multiple_records' => 'If a patient has more than one record for the same stage, each record is exported on its own row with a record_sequence number.',
        ],

        'instructions' => [
            'Select the campaign whose patients you want to export.',
            'Basic patient information is always exported on the Patients sheet.',
            'Optionally select one or more medical record stages, or choose all stages.',
            'Leave all stage checkboxes unchecked to export basic patient data only.',
            'Each selected stage gets its own Excel sheet.',
        ],

        'structure' => [
            'Patients sheet: file_number, name, date of birth, gender, contact, eligibility, admission, current stage, surgery day, rank, side, and notes.',
            'Stage sheets: patient identifiers, record_sequence, record_date, submitter, and all stage fields as readable text.',
            'record_sequence starts at 1 for each patient within the same stage and increments for additional records.',
        ],

        'actions' => [
            'download' => 'Download Excel',
        ],

        'messages' => [
            'failed' => 'Export failed. Please try again or contact support.',
        ],
    ],

    'api' => [
        'messages' => [
            'logged_out' => 'Logged out successfully.',
            'patient_not_in_campaign' => 'You do not have access to patients in this campaign.',
            'campaign_not_accessible' => 'You do not have access to this campaign.',
        ],
    ],

    'messages' => [
        'created' => 'Patient registered successfully.',
        'updated' => 'Patient updated successfully.',
        'deleted' => 'Patient deleted successfully.',
        'attachment_uploaded' => 'Attachment uploaded successfully.',
        'attachment_required' => 'Please select at least one file to upload.',
        'attachment_deleted' => 'Attachment removed successfully.',
        'confirm_delete' => 'Are you sure you want to delete this patient record?',
        'confirm_remove_attachment' => 'Remove this attachment?',
        'empty' => 'No patients found.',
        'no_attachments' => 'No attachments uploaded.',
    ],
];
