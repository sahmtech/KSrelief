<?php

namespace App\Services;

use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\User;
use App\Support\ClinicalCompositeFields;
use App\Support\FollowUpFieldSupport;
use App\Support\OperationFieldSupport;
use App\Support\PostOperationFieldSupport;
use App\Support\PreOperationFieldSupport;
use App\Support\ScreeningFieldSupport;
use App\Support\PatientClinicalFieldRegistry;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;

class MedicalRecordService
{
    public function __construct(
        private readonly PatientClinicalFieldRegistry $fieldRegistry,
    ) {}

    public const AUDIT_CREATED = 'medical_record.created';

    public const AUDIT_UPDATED = 'medical_record.updated';

    public const AUDIT_DELETED = 'medical_record.deleted';

    public function createRecord(Patient $patient, array $data, User $user): MedicalRecord
    {
        return DB::transaction(function () use ($patient, $data, $user): MedicalRecord {
            $record = MedicalRecord::create([
                'patient_id'  => $patient->id,
                'stage_id'    => $data['stage_id'],
                'specialty_id' => $data['specialty_id'] ?? null,
                'record_date' => $data['record_date'],
                'fields_json' => $this->buildFieldsJson($data),
                'notes'       => $data['notes'] ?? null,
                'submitted_by' => $user->id,
            ]);

            // Future: dispatch(new AuditEvent(self::AUDIT_CREATED, $record, $user));

            $record = $record->load(['stage', 'submitter', 'specialty', 'patient']);

            app(\App\Services\Push\DoctorPushNotifier::class)->medicalRecordCreated($record, $user);

            return $record;
        });
    }

    public function updateRecord(MedicalRecord $record, array $data, User $user): MedicalRecord
    {
        return DB::transaction(function () use ($record, $data, $user): MedicalRecord {
            $record->update([
                'stage_id'    => $data['stage_id'] ?? $record->stage_id,
                'specialty_id' => $data['specialty_id'] ?? $record->specialty_id,
                'record_date' => $data['record_date'] ?? $record->record_date,
                'fields_json' => $this->buildFieldsJson($data),
                'notes'       => $data['notes'] ?? $record->notes,
            ]);

            // Future: dispatch(new AuditEvent(self::AUDIT_UPDATED, $record, $user));

            return $record->fresh(['stage', 'submitter', 'specialty']);
        });
    }

    public function deleteRecord(MedicalRecord $record): void
    {
        DB::transaction(function () use ($record): void {
            // Future: dispatch(new AuditEvent(self::AUDIT_DELETED, $record, auth()->user()));
            $record->delete();
        });
    }

    /**
     * @return Collection<int, MedicalRecord>
     */
    public function getPatientRecords(Patient $patient): Collection
    {
        return $patient->medicalRecords()
            ->with(['stage', 'submitter', 'specialty'])
            ->orderBy('record_date', 'desc')
            ->get();
    }

    /**
     * Extract the stage-specific dynamic fields from the request data.
     * All fields prefixed with 'field_' are stored in fields_json.
     *
     * @return array<string, mixed>
     */
    private function buildFieldsJson(array $data): array
    {
        $fields = [];
        $stageCode = null;

        if (! empty($data['stage_id'])) {
            $stageCode = \App\Models\PatientStage::query()->find($data['stage_id'])?->code;
        }

        $stageFieldDefinitions = $stageCode
            ? $this->fieldRegistry->getStageFields($stageCode)
            : [];

        foreach ($data as $key => $value) {
            if (str_starts_with($key, 'field_')) {
                $fieldKey = substr($key, 6);
                $fields[$fieldKey] = $this->normalizeFieldValue(
                    $fieldKey,
                    $value,
                    $stageFieldDefinitions[$fieldKey] ?? []
                );
            }
        }

        // Also support explicit 'fields' key from API
        if (isset($data['fields']) && is_array($data['fields'])) {
            $fields = array_merge($fields, $data['fields']);
        }

        return $fields;
    }

    /**
     * @param  array<string, mixed>  $fieldDefinition
     */
    private function normalizeFieldValue(string $fieldKey, mixed $value, array $fieldDefinition = []): mixed
    {
        $type = $fieldDefinition['type'] ?? '';

        if (($fieldKey === 'clinical_aud' || $type === 'clinical_aud') && is_array($value)) {
            $keys = ClinicalCompositeFields::metricsKeysFromDefinition($fieldDefinition);
            $withStatus = (bool) ($fieldDefinition['with_status'] ?? true);

            return ClinicalCompositeFields::normalizeAud($value, $keys, $withStatus);
        }

        if ($type === 'clinical_speech_followup' && is_array($value)) {
            $keys = config('patient_clinical.clinical_speech_follow_up_keys', ['Cap', 'SIR']);

            return ClinicalCompositeFields::normalizeSpeechFollowup($value, $keys);
        }

        if (($fieldKey === 'clinical_speech' || $type === 'clinical_speech') && is_array($value)) {
            return ClinicalCompositeFields::normalizeSpeech($value);
        }

        if ($type === 'expandable_checklist' && is_array($value)) {
            return ScreeningFieldSupport::normalizeExpandableChecklist(
                $value,
                $fieldDefinition['options'] ?? [],
                $fieldDefinition
            );
        }

        if ($type === 'medical_history_screening' && is_array($value)) {
            return ScreeningFieldSupport::normalizeMedicalHistoryScreening($value);
        }

        if ($type === 'imaging_findings' && is_array($value)) {
            return ScreeningFieldSupport::normalizeImagingFindings($value);
        }

        if ($type === 'follow_up_clinical_assessment' && is_array($value)) {
            return FollowUpFieldSupport::normalizeClinicalAssessment($value);
        }

        if ($type === 'follow_up_audiology_assessment' && is_array($value)) {
            return FollowUpFieldSupport::normalizeAudiologyAssessment($value);
        }

        if ($type === 'follow_up_speech_assessment' && is_array($value)) {
            return FollowUpFieldSupport::normalizeSpeechAssessment($value);
        }

        if ($type === 'follow_up_notes') {
            return FollowUpFieldSupport::normalizeNotes($value);
        }

        if ($type === 'pre_op_physician_assessment' && is_array($value)) {
            return PreOperationFieldSupport::normalizePhysicianAssessment($value);
        }

        if ($type === 'pre_op_audiology_decision' && is_array($value)) {
            return PreOperationFieldSupport::normalizeAudiologyDecision($value);
        }

        if ($type === 'pre_op_speech_assessment' && is_array($value)) {
            return PreOperationFieldSupport::normalizeSpeechAssessment($value);
        }

        if ($type === 'operation_insertion_depth' && is_array($value)) {
            return OperationFieldSupport::normalizeInsertionDepth($value);
        }

        if ($type === 'operation_audio_test' && is_array($value)) {
            return OperationFieldSupport::normalizeAudioTest($value);
        }

        if ($type === 'operation_intra_op_findings') {
            return filled($value) ? (string) $value : null;
        }

        if ($type === 'post_op_physician_assessment' && is_array($value)) {
            return PostOperationFieldSupport::normalizePhysicianAssessment($value);
        }

        if ($type === 'post_op_clinical_aud' && is_array($value)) {
            return PostOperationFieldSupport::normalizeClinicalAud($value);
        }

        if ($type === 'post_op_notes') {
            return PostOperationFieldSupport::normalizeNotes($value);
        }

        return $value;
    }

    /**
     * @return array<string, array{label: string, type: string, required: bool}>
     */
    public function getStageFields(string $stageCode): array
    {
        return $this->fieldRegistry->getStageFields($stageCode);
    }

    public function phaseForStage(string $stageCode): string
    {
        return $this->fieldRegistry->phaseForStage($stageCode);
    }

    /**
     * @return array<string, array{label: string, color: string, background: string}>
     */
    public function clinicalPhases(): array
    {
        return $this->fieldRegistry->phases();
    }

    /**
     * @return array<string, array{label: string, type: string, required: bool}>
     */
    public function getScreeningFields(): array
    {
        return $this->fieldRegistry->eligibilityScreeningFields();
    }

    /**
     * @return array<string, array{label: string, type: string, required: bool}>
     */
    public function getEligibilityScreeningFields(): array
    {
        return $this->fieldRegistry->eligibilityScreeningFields();
    }

    public function createPreOperationRecordIfFilled(Patient $patient, array $data, User $user): ?MedicalRecord
    {
        $stageId = \App\Models\PatientStage::query()
            ->where('code', 'pre_operation')
            ->value('id');

        if (! $stageId) {
            return null;
        }

        $recordData = [
            'stage_id' => (int) $stageId,
            'record_date' => now()->toDateString(),
            'notes' => null,
        ];

        foreach ($data as $key => $value) {
            if (str_starts_with($key, 'field_')) {
                $recordData[$key] = $value;
            }
        }

        $fieldsJson = $this->buildFieldsJson($recordData);
        $definitions = $this->fieldRegistry->getStageFields('pre_operation');

        $hasContent = false;
        foreach ($fieldsJson as $fieldKey => $value) {
            if (ClinicalCompositeFields::hasContent($fieldKey, $value, $definitions[$fieldKey] ?? [])) {
                $hasContent = true;
                break;
            }
        }

        if (! $hasContent) {
            return null;
        }

        return $this->createRecord($patient, $recordData, $user);
    }

    /**
     * Get the latest medical record per stage for a patient.
     *
     * @return Collection<int, MedicalRecord>
     */
    public function getLatestRecordsByStage(Patient $patient): Collection
    {
        return $patient->medicalRecords()
            ->with(['stage', 'submitter'])
            ->orderByDesc('record_date')
            ->orderByDesc('id')
            ->get()
            ->unique('stage_id')
            ->values();
    }
}
